(defproject Roques "Боже убей меня."
  :description "Vasy3r\\k"
  :main ^:skip-aot server
  :url "https://github.com/Chaiok/Roques"
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [server-socket "1.0.0"]])
