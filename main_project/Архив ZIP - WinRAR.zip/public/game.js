var socket = io();
var $all_messages = $("#all_mess");
$('form').submit(function () {
    socket.emit('chat message', $('#m').val());
    $('#m').val('');
    return false;
});
socket.on('add mess', function (data) {
    var decoder = new TextDecoder("utf-8");
    var per = decoder.decode(new Uint8Array(data.msg));
    //$('#otvet').val(per);
    $all_messages.append("<div >" + per + "</div>");
});
//game функции
/*
var movement = {
    up: false,
    down: false,
    left: false,
    right: false
}
document.addEventListener('keydown', function (event) {
    switch (event.keyCode) {
        case 65: // A
            movement.left = true;
            break;
        case 87: // W
            movement.up = true;
            break;
        case 68: // D
            movement.right = true;
            break;
        case 83: // S
            movement.down = true;
            break;
    }
});
document.addEventListener('keyup', function (event) {
    switch (event.keyCode) {
        case 65: // A
            movement.left = false;
            break;
        case 87: // W
            movement.up = false;
            break;
        case 68: // D
            movement.right = false;
            break;
        case 83: // S
            movement.down = false;
            break;
    }
});
setInterval(function () {
    socket.emit('movement', movement);
}, 1000 / 60);
*/
//обработка графики и state
var canvas = document.getElementById('canvas');
canvas.width = 800;
canvas.height = 600;
var context = canvas.getContext('2d');
socket.on('state', function (players) {
    context.clearRect(0, 0, 800, 600);
    context.fillStyle = 'green';
    console.log("players.msg: " + players.msg);
    var decoder = new TextDecoder("utf-8");
    var per = decoder.decode(new Uint8Array(players.msg));
    console.log("per:" + per);
    console.log(typeof per);
    var string = new TextDecoder("utf-8").decode(players.msg);
    console.log("string:" + string);
    //console.log(JSON.parse(String.fromCharCode.apply(null, new Uint8Array(players.msg))));
    var test = "";
    for (var key in per) {
        // этот код будет вызван для каждого свойства объекта
        // ..и выведет имя свойства и его значение

        // console.log("Ключ: " + key + " значение: " + per[key]);
        if (per[key] == '{')
            test = test + per[key] + "'";
        else if (per[key] == ':')
            test = test + per[key] + "'";
        else
            test = test + per[key];
    }
    console.log('test:' + test);

    var myobj = JSON.parse(string);
    //for (var [k, v] in myobj) {
    //    console.log("myobjk:" + k, "\nmyobjv:" + v);
    //}
});